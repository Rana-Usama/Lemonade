export default {
    primary: "#fff",
    pink: '#e93382',
    lightWhite: '#f7f7f7',
    greyNew: '#5c5c5c',
    darkGrey2: '#2D2D2D',
    newInputFieldBorder: '#DEDEDE',
    grey: "#d5d5d5",
    twoButtons: '#F5F5F5',
    blue: '#3A82FF',
    darkGrey: '#707070',
    inputFieldBorder: "#393939",
    inputFieldBackgroundColor: "#efefef",
    inputFieldPlaceholder: "#9AA3AE",
    white: "#fff",
    black: "black",
    lightBlue: '#C0FAEB',
    useNameScreenTopView: '#d218a7'
};
